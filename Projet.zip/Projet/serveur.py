from flask import Flask, render_template, redirect, url_for
from flask import request

app = Flask(__name__)

@app.route("/")
def projet():
    return render_template("projet.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/traitement", methods=["POST", "GET"])
def traitement():
    if request.method == "POST":
        nom = request.form['nom']
        mdp = request.form['mdp']
        print(nom, mdp)
        if nom == 'admin' and mdp == '1234':
            # Rediriger vers la page Animaux.html
            return redirect(url_for('animaux'))
        else:
            return "Un problème est survenu."

@app.route("/animaux")
def animaux():
    return render_template("Animaux.html")

if __name__ == '__main__':
    app.run(debug=True)
